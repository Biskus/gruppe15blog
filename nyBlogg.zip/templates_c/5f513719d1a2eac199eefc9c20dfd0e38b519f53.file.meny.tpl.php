<?php /* Smarty version Smarty-3.0.6, created on 2012-03-08 00:44:17
         compiled from ".\templates\meny.tpl" */ ?>
<?php /*%%SmartyHeaderCode:33364f5800e141d044-42049883%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5f513719d1a2eac199eefc9c20dfd0e38b519f53' => 
    array (
      0 => '.\\templates\\meny.tpl',
      1 => 1331167453,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '33364f5800e141d044-42049883',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<div id="meny">
	<ul>
		<li><a href="index.php">Hjem</a></li>
		<li><a href="nyttInnlegg.php">Lag innlegg</a></li>
		<li><a href="omMeg.php">Om Meg</a></li>
	</ul>
</div>