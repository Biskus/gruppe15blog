<?php /* Smarty version Smarty-3.0.6, created on 2012-03-08 00:50:46
         compiled from ".\templates\omMeg.tpl" */ ?>
<?php /*%%SmartyHeaderCode:114254f580266bdb131-35673365%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1b6f299957447312ff3a19e21beda3431d3d14ce' => 
    array (
      0 => '.\\templates\\omMeg.tpl',
      1 => 1331167843,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '114254f580266bdb131-35673365',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
<?php $_template = new Smarty_Internal_Template('header.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php $_template->updateParentVariables(0);?><?php unset($_template);?>
<h2>Om meg</h2>
<p>
Navn: Kjartan Horpestad <br />
Sivilstatus : Gift og har en datter pluss et barn p� vei<br />
Alder: 21<br />
Litt om meg selv: <br />
	Jeg er en avslappet type som nyter hver dag med min fantastiske famile.
</p>
<img src="mittBilde.jpg" alt="Bilde av familien" />
<?php $_template = new Smarty_Internal_Template('footer.tpl', $_smarty_tpl->smarty, $_smarty_tpl, $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, null, null);
 echo $_template->getRenderedTemplate();?><?php $_template->updateParentVariables(0);?><?php unset($_template);?>