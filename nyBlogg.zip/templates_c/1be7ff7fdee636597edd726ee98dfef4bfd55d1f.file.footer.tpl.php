<?php /* Smarty version Smarty-3.0.6, created on 2012-03-06 12:11:31
         compiled from ".\templates\footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:145164f55fef3d107c3-10340286%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1be7ff7fdee636597edd726ee98dfef4bfd55d1f' => 
    array (
      0 => '.\\templates\\footer.tpl',
      1 => 1331035890,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '145164f55fef3d107c3-10340286',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
)); /*/%%SmartyHeaderCode%%*/?>
		</div>
		</div>
	</body>
</html>